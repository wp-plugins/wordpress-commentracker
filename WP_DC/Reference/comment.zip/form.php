<?php
/*
//*************************************************************
Formulario commentracker - Javi Vicente
javi.vicente@gmail.comhttp://javivicente.hazruido.com

Funciona con commentracker
http://javivicente.hazruido.com/codigo-wp/comment.zip

INSTALACION

Editar el archivo comment.inc.php con los siguientes valores
    Son dos grupos de variables, en la primera tienes que poner la misma palabra secreta
    que usaste un poco mas arriba.
    El segundo grupo de variables es para la conexion a MySQL, asi que edita los campos
    que se indican: $host, $user, $pass, $name, que son
    respectivamente HOST de la DB, Usuario, Contrase�a, y Nombre de la base de
    datos.

Este archivo y el recien editado deben estar en el mismo directorio

(No se ha tenido especial cuidado en el dise�o de la pagina web puesto que
va dedicada unicamente al uso del administrador.

El campo contrase�a de la pagina debe coincidir con el editado en el primer
grupo del archivo comment.inc.php

###############################################################*/


### Require WordPress Header

require(dirname(__FILE__).'/wp-blog-header.php');
include 'comment.inc.php';

### Function: Page Title

add_filter('wp_title', 'form_pagetitle');
function form_pagetitle($form_pagetitle) {
	return $form_pagetitle.' &raquo; Formulario Conversaciones Distribuidas';
}
?>
<?php //get_header(); ?>
<?php 

//compruebo si esta relleno el formulario
if ($_GET["title"]!="" && $_GET["url"]!="" && $_GET["url"]!="http://" && $_GET["texto"]!="" && $_GET["passw"]!="")
{
 if ($_GET["passw"] == $access) 
 {
   //conecto con la base de datos usando las variables del otro fichero
   $link = mysql_connect($host, $user, $pass)or die('MySQL error: '.mysql_error());
   mysql_select_db($name, $link);
	 //creo la consulta
   $sql="INSERT into commentracker (id_ct, title, url, text, date, favicon) VALUES ('', '".utf8_decode($_GET["title"])."' , '" . utf8_decode($_GET["url"]) . "' , '" . utf8_decode($_GET["texto"]) . "', '" . time() . "', '')";
	 //ejecuto la consulta
	 $rs = mysql_query($sql, $link);
	 //compruebo que se ha realizado correctamente y muestro mensaje
	   if(mysql_affected_rows($link)!=-1)
	   {
	     //se ha realizado correctamente
		   echo "<br/>Insertado correctamente en la base de datos";
			 exit;
	   }
	   else
	   {
	     echo "La consulta ha fallado";
	   }
	  
 }
 else
 {
  echo "El codigo 'access' (password) no es correcto";
 }
} 
else
{
?>
<!--Cargo el formulario en caso de no recibir valores-->
<?php get_header(); ?>
Introduce los datos correspondientes:<br /><br />
<table>
  <form action="form.php" method="get">
	<center>
  <tr>
	  <td align="right">T&iacute;tulo weblog: </td>
		<td><input type="text" name="title" size="53" maxlength="255"></td>
  </tr>
	<tr>
    <td align="right">URL: </td>
		<td><input type="text"  value="http://" name="url" size="53" maxlength="255"></td>
	</tr>
	<tr>
    <td align="right">Comentario: </td>
		<td><textarea name="texto" rows="6" cols="50"></textarea></td>
	</tr>
	<tr>
    <td align="right">C&oacute;digo de acceso: </td>
		<td><input type="password" name="passw" size="15" maxlength="20"></td>
	</tr>
  </center>
	</table>
	<center>
	  <br /><br /><br />
		<input type="submit" value="Insertar"> 
		<input type="reset" value="Borrar">
	</center>
  </form>
<?php } ?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>