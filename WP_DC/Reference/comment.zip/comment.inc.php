<?php
//1er grupo
$access = "contrase�a";

//2 grupo
$host="ejemplo";
$user="ejemplo";
$pass="ejemplo";
$name="ejemplo";
?>