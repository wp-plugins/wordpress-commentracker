<?

/*
CommenTracker - Sergio �lvarez (xergio)
mail@xergio.net
http://xergio.net
Licencia CC (BY-SA)


Paginaci�n por: Javi Vicente
javi.vicente@gmail.com
http://www.javivicente.com
URL plugin: http://www.javivicente.com/plugins-wordpress/conversaciones-distribuidas/



*** PASOS PARA USAR EL SISTEMA *************************************************


1. Crear la siguiente tabla en la base de datos MySQL

CREATE TABLE commentracker (
    id_ct int(10) unsigned NOT NULL auto_increment,
    title varchar(255) NOT NULL default '',
    url varchar(255) NOT NULL default '',
    text text NOT NULL,
    date int(10) unsigned NOT NULL default '0',
    favicon varchar(100) NOT NULL default '',
    PRIMARY KEY  (id_ct)
);

2. Subir los archivos .php a tu espacio web

3. Crear un marcador/bookmarklet/favorito en tu Firefox (si no usas Firefox 
    mira a ver como funciona tu navegador) con el siguiente Location/direccion:

    javascript:ct_url='http://sitioweb/commentracker.php'; ct_pass='una_contrase�a'; void(z=document.body.appendChild(document.createElement('script'))); void(z.type='text/javascript'); void(z.src=ct_url+'?mode=js'); void(z.id='commentracker');

    Si te fijas hay dos textos, uno es 'http://sitioweb/commentracker.php'
    y otro 'una_contrasena'. Esos dos textos tienes que editarlos, poniendo en
    uno la direccion de tu web, donde guardes el archivo .php, y es otro una
    contrase�a o palabra secreta, la que tu quieras. Las comillas no las quites



4. Edita la l�neas que hay en el fichero comment.inc.php.
    Son dos grupos de variables, en la primera tienes que poner la misma palabra secreta
    que usaste un poco mas arriba.
    El segundo grupo de variables es para la conexion a MySQL, asi que edita los campos
    que se indican: $host, $user, $pass, $name, que son
    respectivamente HOST de la DB, Usuario, Contrase�a, y Nombre de la base de
    datos.

*/

include 'comment.inc.php';



$db = new mysql($host, $user, $pass, $name);
//##############################################################################
//##############################################################################
//##############################################################################

switch ($_GET["mode"]) {
    // Texto a  mostrar en modo Javascript. El comentario es la direcci�n para el
    // bookmark, javascript:void(...
    case "js":

?>

/*
Inspirado en from http://slayeroffice.com/tools/modi/v2.0/modi_help.html
Anade un TAG <script src="">... al documento HTML

javascript:
    ct_url='http://xergio.net/commentracker.php';
    ct_pass='lala';
    void(z=document.body.appendChild(document.createElement('script')));
    void(z.type='text/javascript');
    void(z.src=ct_url+'?mode=js');
    void(z.id='commentracker');
*/

function cm_init() {
    var cm_title = "";
    var cm_textarea = "";
    var cm_obj = null;

    // obtengo todos los tags...

    for (cm_i = 0; cm_i < document.getElementsByTagName("*").length; cm_i++) {
        cm_obj = document.getElementsByTagName("*")[cm_i];

        // guardamos el title, ya que normalmente ponen el t�tulo del art�culo en
        // el <title>

        if (cm_obj.tagName.toLowerCase() == "title") {
            cm_title = cm_obj.innerHTML;
        }

        // el actual es un textarea?

        if (cm_obj.tagName.toLowerCase() == "textarea") {
            if (cm_obj.value.length > 0) // y hay algo escrito?
                if (cm_textarea.length == 0) // si no lo encontramos ya antes
                    // nos pregunta hasta que damos con el textarea bueno
                    if (confirm("Esto es lo que has escrito?\n\n" + cm_obj.value.slice(0, 200) + "..."))
                        cm_textarea = cm_obj.value;
             }
         }

    // si lo encontro no pregunta por el titulo

    if (cm_textarea.length > 0) {
        cm_title = prompt("Titulo de lo que has comentado:", cm_title);

        // todo OK? pues a guardarlo en nuestro DC

        if ((cm_title != null) && (cm_title != "")) {
            cm_ifrm = document.body.appendChild(document.createElement('iframe'));
            cm_ifrm.style.display = 'none';
            cm_ifrm.src = ct_url + '?mode=add&pass=' + encodeURIComponent(ct_pass) + '&url=' + encodeURIComponent(location.href) + "&title=" + encodeURIComponent(cm_title) + "&text=" + encodeURIComponent(cm_textarea);
            cm_ifrm.id = 'ifrmcommentracker';
        }
    }
}

cm_init();
<?
        break;

    case "add":
        if ($_GET["pass"] == $access) {
            $db->query("INSERT INTO commentracker (id_ct, title, url, text, date, favicon) VALUES ('', '" . utf8_decode($_GET["title"]) . "', '" . utf8_decode($_GET["url"]) . "', '" . utf8_decode($_GET["text"]) . "', '" . time() . "', '" . getFavicon(utf8_decode($_GET["url"])) . "')");
            echo "<script type=\"text/javascript\">alert('Comentario guardado!!');</script>";
        } else {
            echo "<script type=\"text/javascript\">alert('No tienes acceso...');</script>";
        }
        break;
    default:        
?>

<?php
### Require WordPress Header

require(dirname(__FILE__).'/wp-blog-header.php');

### Function: UserOnline Page Title

add_filter('wp_title', 'commentracker_pagetitle');
function commentracker_pagetitle($commentracker_pagetitle) {
	return $commentracker_pagetitle.' &raquo; Conversaciones Distribuidas';
}

function get_mes($ingles)
{
  switch ($ingles)
	{
	  case "January":
		   $mes="Enero";
			 break;
	  case "February":
		   $mes="Febrero";
			 break;
	  case "March":
		   $mes="Marzo";
			 break;
	  case "April":
		   $mes="Abril";
			 break;
	  case "May":
		   $mes="Mayo";
			 break;
	  case "Juni":
		   $mes="Junio";
			 break;
	  case "July":
		   $mes="Julio";
			 break;
	  case "August":
		   $mes="Agosto";
			 break;
	  case "September":
		   $mes="Septiembre";
			 break;
	  case "October":
		   $mes="Octubre";
			 break;
	  case "November":
		   $mes="Noviembre";
			 break;
	  case "December":
		   $mes="Diciembre";
			 break;
	}
	return $mes;
}
function get_mes_num($cad)
{
  switch ($cad)
	{
	  case "Enero":
		   $mes_num="01";
			 break;
	  case "Febrero":
		   $mes_num="02";
			 break;
	  case "Marzo":
		   $mes_num="03";
			 break;
	  case "Abril":
		   $mes_num="04";
			 break;
	  case "Mayo":
		   $mes_num="05";
			 break;
	  case "Junio":
		   $mes_num="06";
			 break;
	  case "Julio":
		   $mes_num="07";
			 break;
	  case "Agosto":
		   $mes_num="08";
			 break;
	  case "Septiembre":
		   $mes_num="09";
			 break;
	  case "Octubre":
		   $mes_num="10";
			 break;
	  case "Noviembre":
		   $mes_num="11";
			 break;
	  case "Diciembre":
		   $mes_num="12";
			 break;
	}
	return $mes_num;
}
?>
<?php get_header(); ?>

<div id="commentracker">

    <center><h5>Todo esto no son m&aacute;s que (casi todos) los comentarios que dejo en otras webs que visito. As&iacute; pod&eacute;is saber por d&oacute;nde ando. (<a href="http://microsiervos.com/dc/">inspiraci&oacute;n</a>)</h5>

<i><h6>Puede que algunos comentarios no est&eacute;n disponibles en las webs originales, ya que pueden estar pendientes de moderaci&oacute;n</i><h6></center>

<?php
        //Limito la busqueda
        $TAMANO_PAGINA = 10;
        //examino la pagina a mostrar y el inicio del registro a mostrar
        $pagina = $_GET["pagina"];
        if (!$pagina) {
            $inicio = 0;
            $pagina=1;
        }
        else {
            $inicio = ($pagina - 1) * $TAMANO_PAGINA;
        }

				$link = mysql_connect($host, $user, $pass);
        mysql_select_db($name, $link);

				//miro a ver el numero total de campos que hay en la tabla con esa busqueda
        //inicializo el criterio y recibo cualquier cadena que se desee buscar

        $criterio = "";
        if ($_GET["criterio"]!=""){
           $txt_criterio = $_GET["criterio"];
           $criterio = " where text like '%" . $txt_criterio . "%' or title like '%" . $txt_criterio . "%'";
         }else if ($_GET["mes"]!="" && $_GET["anno"]!="")
				 {
           $mes=$_GET["mes"];
					 $ano=$_GET["anno"];
					 $mes_num=get_mes_num($mes);
					 $fecha_com= mktime(0, 0, 0, (int)$mes_num, 01, (int)$ano);
					 $fecha_fin=mktime(0, 0, 0, (int)($mes_num+1), 01, (int)$ano)-1;
           $criterio = " where date between '" . $fecha_com . "' and '" . $fecha_fin . "'";
				 }

				$query="SELECT * FROM commentracker". $criterio;
        $result = mysql_query($query, $link);
        $num_rows = mysql_num_rows($result);

  			//calculo el total de p�ginas
        $total_paginas = ceil($num_rows / $TAMANO_PAGINA);

				//pongo el numero de registros total, el tamano de pagina y la pagina que se muestra
  			//Si no hay entradas con el criterio especificado muestra mensaje
				if ($num_rows==0)
					 echo "<br /><br /><br /><br />No se han encontrado entradas con el criterio de b&uacute;squeda <strong>".$txt_criterio."</strong>";
				else
				   echo "<div align='right'><h5> P&aacute;gina " . $pagina . " de " . $total_paginas . "<br /> ($num_rows comentarios desde el <br />7 de febrero de 2006 a las 18:41)</h5></div><p>";

				


				mostrar_paginas();
					 
					 
        $blogs = array();

				//consulto la BBDD

				$datas = $db->fetch("SELECT * FROM commentracker " . $criterio . " ORDER BY date DESC limit " . $inicio . "," . $TAMANO_PAGINA);

        foreach ($datas as $data) {
            $url = parse_url($data['url']);
            $crl = $url['scheme'] . (($url['scheme'] == 'http') ? "://" : ".") . $url['host'];
            $blogs[$crl]++;

        echo "<div class=\'ctitem\'>";
        echo "<h2" . (($data["favicon"]) ? " style=\"background: #fff url(" . $data["favicon"] . ") no-repeat center left; padding-left: 20px;\"": "") . "><a target='blank' href=\"" . $data["url"] . "\">" . utf8_encode($data["title"]) . "</a></h2>";
        echo "<p>" . str_replace("\n", "<p />", utf8_encode($data["text"])) . "</p>";
        echo "<span>Fecha: " . date("d/m/Y H:i", $data["date"]) . "</span>";
        echo "</div>";
        }

				
				mostrar_paginas();

?>
<br /><br /><br />

<!--Formulario de b�squeda-->
<form action="commentracker.php" method="get">
Criterio de b&uacute;squeda:
<input type="text" name="criterio" size="22" maxlength="150">
<input type="submit" value="Buscar">
</form> 

<!--sitios mas comentados-->

<br /><br /><br />
    <div class="ctblogs">
        <h3>Sitios donde m&aacute;s he comentado</h3>
        <ul>
<?php

// esto fue idea de Ander - http://phiz.ath.cx/~andres/blog/
//para que salga datos globales los blogs y no resultados parciales de la pagina visualizada
			  $blogs = array();
        $datas = $db->fetch("SELECT * FROM commentracker ORDER BY date DESC");
        foreach ($datas as $data) {
            $url = parse_url($data['url']);
            $crl = $url['scheme'] . (($url['scheme'] == 'http') ? "://" : ".") . $url['host'];
            $blogs[$crl]++;
						}

        arsort($blogs);
        foreach ($blogs as $url => $num)
            if (preg_match('/(https?:\/\/[a-zA-Z0-9\-\.]+)?/', $url, $match))
                printf("<li><a href=\"%s\">%s</a> <span>(%d)</span></li>\n", $match[1], $match[1], $num);
?>
        </ul>
    </div>
</div>

<? php
//NUEVO ******************************************************************
// ******************Busqueda por meses **********************************
//funcion get_mes agregada
?>

<br /><br /><br />
    <div class="ctblogs">
        <h3>Agrupados por meses:</h3>
        <ul>
				
<?php mostrar_meses() ?>

        </ul>
    </div>

<?php
//*****************************FIN****************************************
//************************************************************************
?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
<?
        break;
}
function mostrar_meses() {
        global $db;
			  $meses = array();		
        $datas = $db->fetch("SELECT * FROM commentracker ORDER BY date DESC");
        foreach ($datas as $data) {
				    $mes=date("F", $data["date"]);
						$mes=get_mes($mes);
						$ano=date("Y", $data["date"]);
            $cad=$mes . " " . $ano;
						$meses[$cad]++;		
						}
        arsort($meses);
        foreach ($meses as $mes => $num)
			  {
                $pos=strpos($mes, " ");
								$month=substr($mes, 0, $pos);
								$anno=substr($mes, ($pos+1));
                printf("<li><a href='commentracker.php?mes=%s&anno=%s'>%s (%d)</a></li>\n", $month, $anno, $mes, $num);
				}

}


function mostrar_paginas(){
     //Muestro la paginacion en la parte superior de la pagina
     //muestro los distintos indices de las paginas, si es que hay varias paginas
		 //muestro solo las 5 anteriores y 5 siguientes paginas en la paginacion
		 global $total_paginas, $pagina, $txt_criterio;
		 //paginas mostradas antes y despues de la pagina principal
		 $pag=5;
		 
		 
    if ($total_paginas > 1){
        echo "<center><h3> P&aacute;ginas: ";
				if (($pagina-$pag)<1) {
				  $pagina_m=1;
				}	else {
					$pagina_m=$pagina-$pag;
				}
					
        for ($i=$pagina_m;$i<=($pagina+$pag)&&$i<$total_paginas;$i++)
				{
          if ($pagina == $i)
            //si muestro el indice de la pagina actual, no coloco enlace
            echo $pagina . " ";
          else 
					 {
             //si el indice no corresponde con la p�gina mostrada actualmente, coloco el enlace para ir a esa pagina
             if ($txt_criterio!="")
						 {
						  echo "<a href='commentracker.php?pagina=" . $i . "&criterio=" . $txt_criterio . "'>" . $i . "</a> ";
						 }
						 else
						 {
						  echo "<a href='commentracker.php?pagina=" . $i . "'>" . $i . "</a> ";
						 }
   				 }
        }
				if ($txt_criterio!=""){
				  echo " ... <a href='commentracker.php?pagina=" . $total_paginas . "&criterio=" . $txt_criterio . "'>" . $total_paginas . "</a> ";
				}
				else {
				  echo " ... <a href='commentracker.php?pagina=" . $total_paginas . "'>" . $total_paginas . "</a> ";
			  }
				echo "</h3></center>";
     }

//termina la paginacion y comienza la visualizacion de resultados

}

//##############################################################################
//##############################################################################
//##############################################################################

class mysql {
    var $conexion;

    function mysql($host, $user, $pass, $name) {
        $this->conexion = @mysql_connect($host, $user, $pass) or die('[1] MySQL error: '.mysql_error());
        mysql_select_db($name, $this->conexion) or die('[2] MySQL error: '.mysql_error());
    }

    function __destruct() {
        //mysql_close($this->conexion);
        // No cierro la conexion porque me ha dado problemas. Tal y como dicen en
        // http://es2.php.net/manual/en/function.mysql-close.php, no hace falta
        // hacerlo en conexiones no persistentes, porque se cierran al terminar
        // la ejecucion del script
    }

    function query($query) {
        $rSQL = mysql_query($query, $this->conexion);
        return $rSQL;
    }

    function fetch($query, $tipo = MYSQL_BOTH) {
        $resultado = mysql_query($query);
        $fetch = array();
        while ($actual = mysql_fetch_array($resultado, $tipo))
            $fetch[] = $actual;
        mysql_free_result($resultado);
        return $fetch;
    }

    function last_id() {
        return mysql_insert_id($this->conexion);
    }

    function error() {
        return mysql_error();
    }
}

// http://www.peej.co.uk/projects/favatars.html modificado

function getFavicon($url) {
    $urlParts = parse_url($url);
    $HTTPRequest = fsockopen($urlParts["host"], 80);
    if ($HTTPRequest) {
        //stream_set_timeout($HTTPRequest, 0.1);
        $hd = "GET " . ((isset($urlParts['path'])) ? $urlParts['path'] : "/").((isset($urlParts['query'])) ? "?".$urlParts['query'] : "") . " HTTP/1.1\n";
        $hd .= "Host: " . $urlParts["host"] . "\n";
        $hd .= "User-Agent: xergioNET - Commentrack System v1\n";
        $hd .= "Connection: Close\n\n";
        fwrite($HTTPRequest, $hd);
        $html = fread($HTTPRequest, 4096);
        $HTTPRequestData = stream_get_meta_data($HTTPRequest);
        fclose($HTTPRequest);

        if (!$HTTPRequestData['timed_out']) {
            if (preg_match('/<link[^>]+rel="(?:shortcut )?icon"[^>]+?href="([^"]+?)"/si', $html, $matches)) {
                $linkUrl = html_entity_decode($matches[1]);
                if (substr($linkUrl, 0, 1) == '/') {
                    $faviconURL = $urlParts['scheme'].'://'.$urlParts['host'].$linkUrl;
                } elseif (substr($linkUrl, 0, 7) == 'http://') {
                    $faviconURL = $linkUrl;
                } elseif (substr($url, -1, 1) == '/') {
                    $faviconURL = $url.$linkUrl;
                } else {
                    $faviconURL = $url.'/'.$linkUrl;
                }
            } else {
                $faviconURL = $urlParts['scheme'].'://'.$urlParts['host'].'/favicon.ico';
            }
            $fiUrlParts = parse_url($faviconURL);
            $HTTPRequest = fsockopen($fiUrlParts["host"], 80);
            if ($HTTPRequest) {
                //stream_set_timeout($HTTPRequest, 0.1);
                $hd = "GET " . ((isset($fiUrlParts['path'])) ? $fiUrlParts['path'] : "/").((isset($fiUrlParts['query'])) ? "?".$fiUrlParts['query'] : "") . " HTTP/1.1\n";
                $hd .= "Host: " . $fiUrlParts["host"] . "\n";
                $hd .= "User-Agent: xergioNET - Commentrack System v1\n";
                $hd .= "Connection: Close\n\n";
                fwrite($HTTPRequest, $hd);
                $favicon = fread($HTTPRequest, 4096);

                if (!preg_match("/^.* 404 Not Found/si", $favicon)) {
                    $HTTPRequestData = stream_get_meta_data($HTTPRequest);
                    fclose($HTTPRequest);
                    if (!$HTTPRequestData['timed_out'] && strlen($favicon) < 4096) {
                        return $faviconURL;
                    }
                }
            }
        }
    }
    return false;
}
?>