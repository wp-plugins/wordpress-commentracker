Atomic - JavaScript Web 2.x Framework
Copyright (c) 2007 by Jonathan L. Brisbin <jon at jbrisbin dot com>
All rights reserved.

Includes some code:
Copyright 2001 Scott Andrew LePera
scott@scottandrew.com
http://www.scottandrew.com/xml-rpc

License: 
You are granted the right to use and/or redistribute this 
code only if this license and the copyright notice are included 
and you accept that no warranty of any kind is made or implied 
by the author.

--

The JavaScript code distributed with Atomic (the "Software") is licensed 
under the GNU (GPL) open source license version 3.

http://www.gnu.org/licenses/gpl.html

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

--

Documentation is available online at:

http://atomic.jbrisbin.com/

You can also get help on how to use the @tomic Web 2.x Ajax Framework in
the appropriate forum.