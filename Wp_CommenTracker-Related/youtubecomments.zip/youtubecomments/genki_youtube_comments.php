<?php
/* 
Plugin Name: Genki Youtube Comments
Version: 1.0
Plugin URI: http://ericulous.com/2007/05/16/wp-plugin-genki-youtube-comments/
Description: Insert YouTube comments into your post's comment
Author: Genkisan
Author URI: http://ericulous.com
*/

add_action ('admin_menu', 'genki_youtube_comments_menu');
add_action('genki_youtube_cron', 'insert_youtube_comments');
add_filter('cron_schedules', 'add_sched_options');

function genki_youtube_comments_menu() {
	add_option('genki_youtube_dev_id', '');
	add_option('genki_youtube_schedule', 'never');
    if (function_exists('add_options_page')) {
		add_options_page('YouTube Comments', 'YouTube Comments', 8, basename(__FILE__), 'genki_youtube_comments_manage');
	}
}

function genki_youtube_comments_manage() {
if (isset($_POST['update_message'])) {

	?><div id="message" class="updated fade"><p><strong><?php

	update_option('genki_youtube_dev_id', $_POST['dev_id']);
	update_option('genki_youtube_schedule', $_POST['schedule']);
	
	if ($_POST['schedule'] == 'never') {
		wp_clear_scheduled_hook('genki_youtube_cron');
	}
	if ($_POST['schedule'] == 'hourly') {
		wp_clear_scheduled_hook('genki_youtube_cron');
		wp_schedule_event(time() + 60, 'hourly', 'genki_youtube_cron');
	}
	if ($_POST['schedule'] == 'daily') {
		wp_clear_scheduled_hook('genki_youtube_cron');
		wp_schedule_event(time() + 60, 'daily', 'genki_youtube_cron');
	}
	if ($_POST['schedule'] == 'weekly') {
		wp_clear_scheduled_hook('genki_youtube_cron');
		wp_schedule_event(time() + 60, 'weekly', 'genki_youtube_cron');
	}

	echo "Options Updated!";

	?></strong></p></div><?php
}

$dev_id = get_option('genki_youtube_dev_id');
$schedule = get_option('genki_youtube_schedule');
?>
	<div class=wrap>
	<h2>Genki Youtube Comments</h2>
		<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
			<fieldset class="options">
				<legend>YouTube Developer ID
					<p>
                    ID: <input name="dev_id" id="dev_id" type="text" value="<?php echo $dev_id ?>" /> 
                    - register for one at <a href="http://youtube.com/my_profile_dev">http://youtube.com/my_profile_dev</a>
					</p>
				</legend>
			</fieldset>
			
            <fieldset class="options">
				<legend>Schedule
				<?php
				global $wp_db_version;
				
				if ( $wp_db_version < 3582 ) {
				?>
				<br />This feature requires Wordpress 2.1
				<?php
				} else {
				?>
				<p>
					<input type="radio" id="schedule" name="schedule" value="never" <?php if ($schedule == 'never') echo 'checked' ; ?> /> Never<br />
					<input type="radio" id="schedule" name="schedule" value="hourly" <?php if ($schedule == 'hourly') echo 'checked' ; ?> /> Once Hourly<br />
					<input type="radio" id="schedule" name="schedule" value="daily" <?php if ($schedule == 'daily') echo 'checked' ; ?> /> Once Daily<br />
					<input type="radio" id="schedule" name="schedule" value="weekly" <?php if ($schedule == 'weekly') echo 'checked' ; ?> /> Once Weekly
				</p>
				<?php
				}
				?>
                <p class="submit">
                    <input type="submit" name="update_message" value="Update Options &raquo;" />
                </p>
                </legend>
			</fieldset>
		</form>
             
        <hr />
        
		<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
			<fieldset class="options">
			<legend>Manual Update</legend>
			<p class="submit">
				<input type="submit" name="manual_update" value="Update comments now &raquo;" />
            </p>
            </fieldset>
		</form>
        
       	<?php 
		if (isset($_POST['manual_update'])) {
			insert_youtube_comments();
        }
		?>
        
        <hr />
        
        <fieldset class="options">
			<legend>Usage
				<p>
                    1. in Manage > Posts, find the post which you want the comments to be inserted.<br />
                    2. go to the Custom Fields section and add "youtubevidid" as key.<br />
                    3. add your YouTube video id e.g X2BEhk1fqZ<br />
                    4. if more than 1 vid, simply add more keys: youtubevidid1, youtubevidid2 and so on<br />
                    <img style="border:1px solid #f00" src="<?php echo bloginfo('home') ?>/wp-content/plugins/youtubecomments/usage.gif" />
				</p>
			</legend>
		</fieldset>
        
	</div>
<?php
}

function add_sched_options($sched) {
	$sched['weekly'] = array('interval' => 604800, 'display' => __('Once Weekly'));
	return $sched;
}

function insert_youtube_comments() {
	global $wpdb;
	require_once('class_xml.php');
	
	$videoposts = $wpdb->get_results("SELECT post_id, meta_value FROM " . $wpdb->prefix . "postmeta WHERE meta_key LIKE 'youtubevidid%'");	

	if ($videoposts) {	
		foreach ($videoposts as $videopost) {
		
			$x = new xml();
		
			$youtube_dev_id = get_option('genki_youtube_dev_id');	
		
			$source = file_get_contents("http://www.youtube.com/api2_rest?method=youtube.videos.get_details&dev_id=$youtube_dev_id&video_id=$videopost->meta_value");
		
			if (!$x->fetch($source)) {
			
			  echo "<h2>There was a problem parsing your XML!</h2>";
			  echo $x->log;
			  exit();
			}
			
			if (($x->data->UT_RESPONSE[0]->_attr->STATUS == 'ok') && ($x->data->UT_RESPONSE[0]->VIDEO_DETAILS[0]->COMMENT_COUNT[0]->_text != 0)) {
				
				foreach ($x->data->UT_RESPONSE[0]->VIDEO_DETAILS[0]->COMMENT_LIST[0]->COMMENT as $ytvideo) {
			
				$comment_post_ID = $videopost->post_id;
				$comment_author = $ytvideo->AUTHOR[0]->_text;
				$comment_author_email = 'api@youtube.com';
				$comment_author_url = 'http://www.youtube.com/profile?user=' . $ytvideo->AUTHOR[0]->_text;
				$comment_author_IP = preg_replace( '/[^0-9., ]/', '',$_SERVER['REMOTE_ADDR'] );
				$comment_date = $ytvideo->TIME[0]->_text;
				$comment_content = ' [..YouTube..] ' . addslashes($ytvideo->TEXT[0]->_text);
				$comment_approved = 1;
				$comment_agent = 'Youtube API';
				$comment_type = '';
				$comment_parent = 0;
				$user_id = 0;
				  
				$recordexist = $wpdb->query("SELECT comment_ID FROM " . $wpdb->prefix . "comments WHERE comment_author = '$comment_author' AND comment_date = FROM_UNIXTIME($comment_date)");

				if (!$recordexist) {
					$result = $wpdb->query("INSERT INTO $wpdb->comments
					(comment_post_ID, comment_author, comment_author_email, comment_author_url, comment_author_IP, comment_date, comment_date_gmt, comment_content, comment_approved, comment_agent, comment_type, comment_parent, user_id)
					VALUES
					('$comment_post_ID', '$comment_author', '$comment_author_email', '$comment_author_url', '$comment_author_IP', FROM_UNIXTIME($comment_date), FROM_UNIXTIME($comment_date), '$comment_content', '$comment_approved', '$comment_agent', '$comment_type', '$comment_parent', '$user_id')
					");
					
					global $wp_db_version;
					
					//WP2.0
					if ( $wp_db_version < 3582 ) {
						$wpdb->query( "UPDATE " . $wpdb->prefix . "posts SET comment_count = comment_count+1 WHERE ID = '$comment_post_ID'" );
					}
					//WP2.1
					else {
						wp_update_comment_count($videopost->post_id);
					}
					
					echo '<strong>Post:</strong> ';
					echo '<a href="' . get_permalink($comment_post_ID) . '">' . get_the_title($comment_post_ID) .'</a>';
					echo '<br /><strong>Author:</strong> ';
					echo $ytvideo->AUTHOR[0]->_text;
					echo '<br /><strong>Comment:</strong> ';
					echo $ytvideo->TEXT[0]->_text;
					//echo '<br />Time';
					//echo $ytvideo->TIME[0]->_text;
					echo '<br /><br />';
					echo 'New Comment inserted.<hr />';
				}
				//else {
				//	echo $ytvideo->AUTHOR[0]->_text;
				//	echo '<br />';
				//	echo $ytvideo->TEXT[0]->_text;
				//	echo '<br />';
				//	echo $ytvideo->TIME[0]->_text;
				//	echo '<br /><br />';
				//	echo 'Comment not inserted. Already exists.<br /><hr />';
				//}
				
				} //foreach ($x->data->UT_RESPONSE[0]->VIDEO_DETAILS[0]->COMMENT_LIST[0]->COMMENT as $ytvideo)
			}
			else {
				//if ($x->data->UT_RESPONSE[0]->VIDEO_DETAILS[0]->COMMENT_COUNT[0]->_text == 0) {
				//	echo '<strong>Post:</strong> ';
				//	echo get_the_title($comment_post_ID);
				//	echo 'No comments found for this post<br />';
				//}
				if ($x->data->UT_RESPONSE[0]->_attr->STATUS != 'ok') {
					$comment_post_ID = $videopost->post_id;
					echo '<a href="' . get_permalink($comment_post_ID) . '">' . get_the_title($comment_post_ID) .'</a><br />';
					echo 'Error retrieving data from YouTube<br />';
					//echo $x->data->UT_RESPONSE[0]->_attr->STATUS;
					echo $x->data->UT_RESPONSE[0]->ERROR[0]->DESCRIPTION[0]->_text;
					echo '<br />';
				}
			}
		
		} //foreach ($videoposts as $videopost)
	} //if (!videoposts)
} //function insert_youtube_comments()
?>
