=== Plugin Name ===
Contributors: Genkisan
Tags: youtube, comments
Requires at least: 2.0.0
Tested up to: 2.1.3
Stable tag: 1.0.0

Grab YouTube video comments and insert into your blog post

== Description ==

- grab youtube video comments and insert into your blog post
- schedule hourly, daily, weekly (for WP 2.1)
- manual update


== Installation ==

1. Upload as a folder and activate plugin
2. Go to Admin Panel > Options > YouTube Comments.
3. Enter your YouTube Developer ID (register for it at http://youtube.com/my_profile_dev)
4. Set schedule or update manually.
5. in Manage > Posts, find the post which you want the comments to be inserted.
6. go to the Custom Fields section and add ��youtubevidid�� as key.
7. add your YouTube video id e.g X2BEhk1fqZ
8. if more than 1 vid, simply add more keys: youtubevidid1, youtubevidid2 and so on

== Screenshots ==

1. Admin Panel
2. Insert post meta